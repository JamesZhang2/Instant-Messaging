type msg = {
  sender : string;
  receiver : string;
  time : string;
  message : string;
}

let post_method_response = failwith "Unimplemented"
let get_method_response = failwith "Unimplemented"
let error_response = failwith "Unimplemented"