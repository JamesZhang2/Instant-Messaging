(** @canonical Client.Controller *)
module Controller = Client__Controller


(** @canonical Client.Interface *)
module Interface = Client__Interface


(** @canonical Client.Network *)
module Network = Client__Network


(** @canonical Client.Packager *)
module Packager = Client__Packager


(** @canonical Client.Parser *)
module Parser = Client__Parser
